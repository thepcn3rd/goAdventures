
```cmd
sc.exe create THMservice-n3rd binPath= "%windir%\myService1.exe" start= auto
```