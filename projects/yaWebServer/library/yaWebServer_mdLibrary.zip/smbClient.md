smbclient usefull commands

Execute a command which copies a file to the share location...
```bash
smbclient -c 'put myService1.exe' -U t1_leonard.summers -W ZA '//thmiis.za.tryhackme.com/admin$/' EZpass4ever
```