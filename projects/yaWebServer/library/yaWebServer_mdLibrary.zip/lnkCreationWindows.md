# Overview
MITRE ATTACK
Tactic: Execution
Technique ID: T1204.T1204.002
Technique: User Execution
Sub-Technique: Malicious File

tags: #execution #powershell #lnkfiles #windows 

# Description

Create a lnk file that embeds a payload in the arguments section of the LNK file.  This is an attack vector to hide payloads.

# References:
URL: https://www.trendmicro.com/en_ph/research/17/e/rising-trend-attackers-using-lnk-files-download-malware.html

URL: https://gist.github.com/vector-sec/05733c8758005cd6c4da2e1926917dce # Create lnk files with a payload for powershell

URL: https://github.com/hexachordanu/Red-Team-Essentials/blob/master/Generate-LNK.ps1


# Creation of LNK Files

### Powershell

```powershell
$shellObject = New-Object -ComObject WScript.Shell
# Specifically creating the extension so that it can be copied
$newLNK = $shellObject.CreateShortcut("c:\users\administrator\desktop\new.lnk") 
$newLNK.TargetPath = "C:\windows\system32\cmd.exe"
$newLNK.WindowStyle = 1 # Could be 3 or 7 refer to specs of LNK from Microsoft v5
$newLNK.IconLocation = "C:\windows\system32\cmd.exe"
$newLNK.WorkingDirectory = "c:\users\public\"

# The arguments can be upwards of 4096 characters the below
# generates a string that is 4000 characters long to embed in the arguments section
$charString = -join ((65..90) + (97..122) | Get-Random -Count 4000 | ForEach-Object {[char]$_})
$newLNK.Arguments = $charString
$newLNK.Description = "This is not the droid you are looking for..."
$newLNK.Save()
```


